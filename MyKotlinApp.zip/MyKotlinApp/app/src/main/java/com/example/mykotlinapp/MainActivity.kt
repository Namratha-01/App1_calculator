package com.example.mykotlinapp

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity(), View.OnClickListener {

    lateinit var spinner: Spinner
    lateinit var etA: EditText
    lateinit var etB: EditText
    lateinit var res: TextView
    lateinit var btn: Button
    lateinit var receivedText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        etA = findViewById(R.id.et_a)
        etB = findViewById(R.id.et_b)
        res = findViewById(R.id.result)
        btn = findViewById(R.id.button)
        spinner = findViewById(R.id.spinner_operations)
        receivedText = findViewById(R.id.receivedText)

        btn.setOnClickListener(this)

        val text = intent.getStringExtra("EXTRA_TEXT")
        if (text != null) {
            receivedText.text = "Received: $text"
        }
    }

    override fun onClick(v: View?) {
        var a = etA.text.toString().toDouble()
        var b = etB.text.toString().toDouble()
        var result = 0.0
        when (spinner.selectedItem.toString()) {
            "add" -> {result = a + b}
            "sub" -> {result = a - b}
            "mul" -> {result = a * b}
            "div" -> {result = a / b}
        }
        res.text = "Result is $result"
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.item1 -> {
                Toast.makeText(this, "item 1 selected", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.item2 -> {
                Toast.makeText(this, "item 2 selected", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.item3 -> {
                Toast.makeText(this, "item 3 selected!", Toast.LENGTH_SHORT).show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
